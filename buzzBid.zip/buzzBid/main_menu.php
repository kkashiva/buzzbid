<?php
include('lib/common.php');

// Check if user is logged in
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

// Fetch user information from session
$userusername = $_SESSION['username'];

// Fetch user information from the database
$query = "SELECT first_name, last_name FROM User WHERE user_name='$userusername'";
$result = mysqli_query($db, $query);

// Check if the query was successful
if ($result) {
    // Fetch the user's first name and last name
    $row = mysqli_fetch_assoc($result);
    $userFirstName = $row['first_name'];
    $userLastName = $row['last_name'];
} else {
    // Handle error if the query fails
    die("Error fetching user information: " . mysqli_error($db));
}

$adminPosition = ''; // Fetch admin position from database or session if user is an admin

// Determine menu options based on user type
$menuOptions = [
    ['label' => 'Search for Items', 'url' => 'search_items.php'],
    ['label' => 'List an Item for Sale', 'url' => 'list_item.php'],
    ['label' => 'View Auction Results', 'url' => 'view_auction_results.php']
];

if ($userType === 'admin') {
    // Add admin-specific menu options
    $menuOptions[] = ['label' => 'Generate Report 1', 'url' => 'generate_report_1.php'];
    $menuOptions[] = ['label' => 'Generate Report 2', 'url' => 'generate_report_2.php'];
    // Add more admin menu options as needed
}
?>

<?php include("lib/header.php"); ?>
<title>Main Menu</title>
</head>
<body>
    <div class="header">
        <h1></h1>
    </div>
	<div class="login-box">
    <span class="close">&#10006;</span> <!-- Close symbol -->

	<p class="login-box::before">Main Menu</p>
	<img class="login-image" src="img/Buzzbid.png" alt="Image Description">
	<h3>Welcome, <?php echo $userFirstName . " " . $userLastName; ?></h3>
    <?php if ($userType === 'admin') { ?>
        <p>Position: <?php echo $adminPosition; ?></p>
    <?php } ?>
    <ul>
        <?php foreach ($menuOptions as $option) { ?>
            <li><a href="<?php echo $option['url']; ?>"><?php echo $option['label']; ?></a></li>
        <?php } ?>
        <li><a href="logout.php">Logout</a></li>
    </ul>
	<?php include("lib/error.php"); ?>
</div>

    <?php?>
</body>
</html>