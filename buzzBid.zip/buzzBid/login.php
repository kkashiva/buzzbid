<?php
//this page utilized the GTOnline sample project for OMSCS 6400
include('lib/common.php');

/*if($showQueries){
  array_push($query_msg, "showQueries currently turned ON, to disable change to 'false' in lib/common.php");
}*/

// Handle form submission when the "Login" button is clicked
if( $_SERVER['REQUEST_METHOD'] == 'POST') {

    $enteredusername = mysqli_real_escape_string($db, $_POST['username']);
    $enteredPassword = mysqli_real_escape_string($db, $_POST['password']);

    if (empty($enteredusername)) {
        array_push($error_msg,  "Please enter an username address.");
    }

    if (empty($enteredPassword)) {
        array_push($error_msg,  "Please enter a password.");
    }

    if ( !empty($enteredusername) && !empty($enteredPassword) )   { 

        $query = "SELECT password FROM User WHERE user_name='$enteredusername'";
        
        $result = mysqli_query($db, $query);
        //include('lib/show_queries.php');
        $count = mysqli_num_rows($result); 
        
        if (!empty($result) && ($count > 0) ) {
            $row = mysqli_fetch_array($result, MYSQLI_ASSOC);
            $storedPassword = $row['password']; 
            
            $options = [
                'cost' => 8,
            ];
            // Convert the plaintext passwords to their respective hashses
            $storedHash = password_hash($storedPassword, PASSWORD_DEFAULT , $options);   // May not want this if $storedPassword are stored as hashes (don't rehash a hash)
            $enteredHash = password_hash($enteredPassword, PASSWORD_DEFAULT , $options); 
            
            /*if($showQueries){
                array_push($query_msg, "Plaintext entered password: ". $enteredPassword);
                // Note: because of salt, the entered and stored password hashes will appear different each time
                array_push($query_msg, "Entered Hash:". $enteredHash);
                array_push($query_msg, "Stored Hash:  ". $storedHash . NEWLINE);  // Note: Change to storedHash if tables store the plaintext password value
                // Unsafe, but left as a learning tool. Uncomment if you want to log passwords with hash values
                // error_log('username: '. $enteredusername  . ' password: '. $enteredPassword . ' hash:'. $enteredHash);
            }*/
            
            // Depending on if you are storing the hash $storedHash or plaintext $storedPassword 
            if (password_verify($enteredPassword, $storedHash) ) {
                array_push($query_msg, "Password is Valid! ");
                $_SESSION['username'] = $enteredusername;
                array_push($query_msg, "Logging in... ");
                header(REFRESH_TIME . 'url=main_menu.php'); // To view the password hashes and login success/failure
                
            } else {
                array_push($error_msg, "Login failed: " . $enteredusername . NEWLINE);
				array_push($error_msg, "Password is incorrect." );
                //array_push($error_msg, "To demo enter: ". NEWLINE . "michael@bluthco.com". NEWLINE ."michael123");
            }
            
        } else {
            array_push($error_msg, "The username entered does not exist: " . $enteredusername);
        }
    }
}
?>

<?php include("lib/header.php"); ?>
<title>Buzzbid Login</title>
</head>
<body>
    <div id="main_container">
        <div id="header">
            <div class="title" style="color: white;">Buzzbid Login</div>
            <div class="logo">
                <img src="img/Buzzbid.png" style="opacity:0.5;background-color:white;" border="0" alt="" title="Buzzbid Logo"/>
            </div>
        </div>

        <div class="center_content">
            <div class="text_box">
                <form action="#" method="post" enctype="multipart/form-data">
                    <div class="login_form_row">
                        <label class="login_label">Username:</label>
                        <input type="text" name="username" value="salini" class="login_input"/>
                    </div>
                    <div class="login_form_row">
                        <label class="login_label">Password:</label>
                        <input type="password" name="password" value="salini123" class="login_input"/>
                    </div>
                    <button type="submit" name="login" class="login">Login</button>
                    <button type="button" class="register">Register</button>
                </form>
            </div>
            <?php include("lib/error.php"); ?>
            <div class="clear"></div>
        </div>
    </div>

    <script>
        // JavaScript code to handle redirection when the "Register" button is clicked
        document.querySelector('.register').addEventListener('click', function() {
            window.location.href = 'register.php';
        });
    </script>

    <?php?>
</body>
</html>